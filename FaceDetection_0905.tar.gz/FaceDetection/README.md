## SeetaFace Detection



### How to Build in Linux
- Build
```shell
mkdir build
cd build
cmake ..
make
```

- Run demo
```shell

./build/facedet_test 0_1_1.jpg model/seeta_fd_frontal_v1.0.bin
./build/facedet_camera

```


